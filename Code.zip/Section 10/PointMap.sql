--Data provided by Google Maps
--Create the table
create table dbo.tblFloridaPublicUniversities
(
  pKey int identity(1,1) PRIMARY KEY,
  ShortDescription varchar(4),
  LongDescription varchar(64),
  Latitude float,
  Longitude float,
  Point geography
)
--insert records
insert into dbo.tblFloridaPublicUniversities values ('UWF',  'University of West Florida',  30.5418883, -87.2208534, NULL)
insert into dbo.tblFloridaPublicUniversities values ('USF',  'University of South Florida', 28.0587078, -82.4160426, NULL)
insert into dbo.tblFloridaPublicUniversities values ('UNF',  'University of North Florida', 30.2687,    -81.5096712, NULL)
insert into dbo.tblFloridaPublicUniversities values ('UF',   'University of Florida',       29.6436371, -82.3571189, NULL)
insert into dbo.tblFloridaPublicUniversities values ('UCF',  'University of Central Florida', 28.6024321, -81.2022486, NULL)
insert into dbo.tblFloridaPublicUniversities values ('NCF',  'New College of Florida', 27.3848327, -82.5608917, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FSU',  'Florida State University', 30.4418824, -84.3006776, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FPU',  'Florida Polytechnic University', 28.1507452, -81.8534423, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FIU',  'Florida International University', 25.7565804, -80.3761374, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FGCU', 'Florida Gulf Coast University', 26.4640539, -81.7758166, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FAU',  'Florida Atlantic University', 26.3706218, -80.10420484, NULL)
insert into dbo.tblFloridaPublicUniversities values ('FAMU', 'Florida Agricultural and Mechanical University', 30.425613,-84.2894265, NULL)


--update the Point column which is a geography data type
update dbo.tblFloridaPublicUniversities 
set Point=
geography::STPointFromText('POINT('+CAST(Longitude AS VARCHAR(10))+' '+CAST(Latitude AS VARCHAR(10))+')', 4326)

--The following query is used in the video
select ShortDescription, Point from dbo.tblFloridaPublicUniversities

