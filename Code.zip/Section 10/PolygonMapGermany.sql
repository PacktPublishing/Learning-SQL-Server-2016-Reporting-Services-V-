--Create the table
create table dbo.PopulationOfGermanStates
(
   pKey integer identity(1,1) primary key,
   StateName varchar(30),
   StatePopulation bigint 
)
--insert records

insert into dbo.PopulationOfGermanStates values('Baden-W�rttemberg', 10755000)
insert into dbo.PopulationOfGermanStates values('Bayern',12542000)
insert into dbo.PopulationOfGermanStates values('Berlin',3469000)
insert into dbo.PopulationOfGermanStates values('Brandenburg',2500000)
insert into dbo.PopulationOfGermanStates values('Bremen',661000)
insert into dbo.PopulationOfGermanStates values('Hamburg',1788000)
insert into dbo.PopulationOfGermanStates values('Hessen',6066000)
insert into dbo.PopulationOfGermanStates values('Niedersachsen',7914000)
insert into dbo.PopulationOfGermanStates values('Mecklenburg-Vorpommern',163900)
insert into dbo.PopulationOfGermanStates values('Nordrhein-Westfalen',17837000)
insert into dbo.PopulationOfGermanStates values('Rheinland-Pfalz',3999000)
insert into dbo.PopulationOfGermanStates values('Saarland',1018000)
insert into dbo.PopulationOfGermanStates values('Sachsen',4143000)
insert into dbo.PopulationOfGermanStates values('Sachsen-Anhalt',2331000)
insert into dbo.PopulationOfGermanStates values('Schleswig-Holstein',2833000)
insert into dbo.PopulationOfGermanStates values('Th�ringen',2231000)

--The following query is used in the video
select StateName, StatePopulation from dbo.PopulationOfGermanStates