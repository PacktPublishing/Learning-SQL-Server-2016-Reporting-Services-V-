--Data provided by Google
--Create the table
create table dbo.tblFlightsFromEuropeToMumbai
(
  pKey int identity(1,1) PRIMARY KEY,
  ShortDescription varchar(7),
  LongDescription varchar(64),
  Duration int, 
  StartLatitude float,
  StartLongitude float,
  EndLatitude float,
  EndLongitude float,
  LineString geography
)

--insert records
insert into dbo.tblFlightsFromEuropeToMumbai values ('LHR', 'London',    590, 51.4700256,-0.4564842, 19.0895646,72.8634257, NULL)
insert into dbo.tblFlightsFromEuropeToMumbai values ('CDG', 'Paris',     595, 49.0096941, 2.5457358,  19.0895646,72.8634257, NULL)
insert into dbo.tblFlightsFromEuropeToMumbai values ('AMS', 'Amsterdam', 580, 52.3105419, 4.7660857,  19.0895646,72.8634257, NULL)
insert into dbo.tblFlightsFromEuropeToMumbai values ('IST', 'Istanbul',  420, 40.9808334,28.8054726, 19.0895646,72.8634257, NULL)
insert into dbo.tblFlightsFromEuropeToMumbai values ('FRA', 'Frankfurt', 475, 50.0379326, 8.5599631, 19.0895646,72.8634257, NULL)
insert into dbo.tblFlightsFromEuropeToMumbai values ('ZRH', 'Zurich',    495, 47.4582165, 8.5532868, 19.0895646,72.8634257, NULL)

--update the LineString column which is a geography data type
update dbo.tblFlightsFromEuropeToMumbai 
set LineString=
geography::STLineFromText('LINESTRING(' + 
CAST(EndLongitude AS VARCHAR(10)) + ' ' + CAST(EndLatitude AS VARCHAR(10)) + ', ' +
CAST(StartLongitude AS VARCHAR(10)) + ' ' + CAST(StartLatitude AS VARCHAR(10)) + 
')', 4326)

--The following query is used in the video
select ShortDescription, Duration, LineString 
from dbo.tblFlightsFromEuropeToMumbai
