--Data provided by the Centers for Disease Control on November 30, 2016
--Create the table
create table dbo.tblTravelAssociatedZikaCasesByState
(
   pKey integer identity(1,1) primary key,
   StateName varchar(30),
   StateFIPSCode varchar(2),
   StateAbbreviation varchar(2),
   NumberOfCases integer
)
--insert records
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Alabama','01','AL',30)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Alaska','02','AK',0)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Arizona','04','AZ',49)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Arkansas','05','AR',13)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('California','06','CA',368)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Colorado','08','CO',50)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Connecticut','09','CT',58)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Delaware','10','DE',17)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Florida','12','FL',785)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Georgia','13','GA',102)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Hawaii','15','HI',14)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Idaho','16','ID',4)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Illinois','17','IL',83)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Indiana','18','IN',47)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Iowa','19','IA',17)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Kansas','20','KS',17)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Kentucky','21','KY',24)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Louisiana','22','LA',35)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Maine','23','ME',12)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Maryland','24','MD',110)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Massachusetts','25','MA',105)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Michigan','26','MI',63)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Minnesota','27','MN',55)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Mississippi','28','MS',23)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Missouri','29','MO',36)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Montana','30','MT',7)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Nebraska','31','NE',13)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Nevada','32','NV',18)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('New Hampshire','33','NH',12)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('New Jersey','34','NJ',164)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('New Mexico','35','NM',9)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('New York','36','NY',921)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('North Carolina','37','NC',81)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('North Dakota','38','ND',2)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Ohio','39','OH',74)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Oklahoma','40','OK',29)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Oregon','41','OR',37)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Pennsylvania','42','PA',157)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Rhode Island','44','RI',35)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('South Carolina','45','SC',53)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('South Dakota','46','SD',2)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Tennessee','47','TN',58)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Texas','48','TX',258)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Utah','49','UT',16)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Vermont','50','VT',10)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Virginia','51','VA',94)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Washington','53','WA',58)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('West Virginia','54','WV',11)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Wisconsin','55','WI',46)
insert into dbo.tblTravelAssociatedZikaCasesByState values ('Wyoming','56','WY',2)

--The following query is used in the video
select StateName, 
StateFIPSCode, 
StateAbbreviation,
NumberOfCases
from  dbo.tblTravelAssociatedZikaCasesByState
