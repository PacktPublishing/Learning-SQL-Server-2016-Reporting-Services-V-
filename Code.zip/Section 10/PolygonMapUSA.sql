--Data provided by United States Census Bureau
--Create the table
create table dbo.tblPopulationByState
(
   pKey integer identity(1,1) primary key,
   StateName varchar(30),
   StateFIPSCode varchar(2),
   StateAbbreviation varchar(2),
   StatePopulation integer
)
--insert records
insert into dbo.tblPopulationByState values ('Alabama','01','AL',4858979)
insert into dbo.tblPopulationByState values ('Alaska','02','AK',738432)
insert into dbo.tblPopulationByState values ('Arizona','04','AZ',6828065)
insert into dbo.tblPopulationByState values ('Arkansas','05','AR',2978204)
insert into dbo.tblPopulationByState values ('California','06','CA',39144818)
insert into dbo.tblPopulationByState values ('Colorado','08','CO',5456574)
insert into dbo.tblPopulationByState values ('Connecticut','09','CT',3590886)
insert into dbo.tblPopulationByState values ('Delaware','10','DE',945934)
insert into dbo.tblPopulationByState values ('Florida','12','FL',20271272)
insert into dbo.tblPopulationByState values ('Georgia','13','GA',10214860)
insert into dbo.tblPopulationByState values ('Hawaii','15','HI',1431603)
insert into dbo.tblPopulationByState values ('Idaho','16','ID',1654930)
insert into dbo.tblPopulationByState values ('Illinois','17','IL',12859995)
insert into dbo.tblPopulationByState values ('Indiana','18','IN',6619680)
insert into dbo.tblPopulationByState values ('Iowa','19','IA',3123899)
insert into dbo.tblPopulationByState values ('Kansas','20','KS',2911641)
insert into dbo.tblPopulationByState values ('Kentucky','21','KY',4425092)
insert into dbo.tblPopulationByState values ('Louisiana','22','LA',4670724)
insert into dbo.tblPopulationByState values ('Maine','23','ME',1329328)
insert into dbo.tblPopulationByState values ('Maryland','24','MD',6006401)
insert into dbo.tblPopulationByState values ('Massachusetts','25','MA',6794422)
insert into dbo.tblPopulationByState values ('Michigan','26','MI',9922576)
insert into dbo.tblPopulationByState values ('Minnesota','27','MN',5489594)
insert into dbo.tblPopulationByState values ('Mississippi','28','MS',2992333)
insert into dbo.tblPopulationByState values ('Missouri','29','MO',6083672)
insert into dbo.tblPopulationByState values ('Montana','30','MT',1032949)
insert into dbo.tblPopulationByState values ('Nebraska','31','NE',1896190)
insert into dbo.tblPopulationByState values ('Nevada','32','NV',2890845)
insert into dbo.tblPopulationByState values ('New Hampshire','33','NH',1330608)
insert into dbo.tblPopulationByState values ('New Jersey','34','NJ',8958013)
insert into dbo.tblPopulationByState values ('New Mexico','35','NM',2085109)
insert into dbo.tblPopulationByState values ('New York','36','NY',19795791)
insert into dbo.tblPopulationByState values ('North Carolina','37','NC',10042802)
insert into dbo.tblPopulationByState values ('North Dakota','38','ND',756927)
insert into dbo.tblPopulationByState values ('Ohio','39','OH',11613423)
insert into dbo.tblPopulationByState values ('Oklahoma','40','OK',3911338)
insert into dbo.tblPopulationByState values ('Oregon','41','OR',4028977)
insert into dbo.tblPopulationByState values ('Pennsylvania','42','PA',12802503)
insert into dbo.tblPopulationByState values ('Rhode Island','44','RI',1056298)
insert into dbo.tblPopulationByState values ('South Carolina','45','SC',4896146)
insert into dbo.tblPopulationByState values ('South Dakota','46','SD',858469)
insert into dbo.tblPopulationByState values ('Tennessee','47','TN',6600299)
insert into dbo.tblPopulationByState values ('Texas','48','TX',27469114)
insert into dbo.tblPopulationByState values ('Utah','49','UT',2995919)
insert into dbo.tblPopulationByState values ('Vermont','50','VT',626042)
insert into dbo.tblPopulationByState values ('Virginia','51','VA',8382993)
insert into dbo.tblPopulationByState values ('West Virginia','54','WV',1844128)
insert into dbo.tblPopulationByState values ('Washington','53','WA',7170351)
insert into dbo.tblPopulationByState values ('Wisconsin','55','WI',5771337)
insert into dbo.tblPopulationByState values ('Wyoming','56','WY',586107)

--The following query is used in the video
select StateName, 
StateFIPSCode, 
StateAbbreviation,
StatePopulation
from  dbo.tblPopulationByState
