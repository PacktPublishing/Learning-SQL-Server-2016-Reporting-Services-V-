select distinct Color
from Dimension.[Stock Item]
order by Color
