select 
t3.[Calendar Year] as [Calendar Year],
t3.[Calendar Month Number] as [Month],
t2.[Color] as [Color],
sum(t1.[Quantity]) as [Quantity Ordered],
sum(t1.[Total Excluding Tax]) as [Total Excluding Tax]
from [Fact].[Order] as t1
inner join [Dimension].[Stock Item] as t2 on t1.[Stock Item Key] =t2.[Stock Item Key]
inner join [Dimension].[Date] as t3 on t1.[Order Date Key]=t3.[Date]
group by t3.[Calendar Year], t3.[Calendar Month Number], t2.[Color]
order by t3.[Calendar Year], t3.[Calendar Month Number], t2.[Color]
